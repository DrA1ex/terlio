#!/usr/bin/env node
import { RichTerminalApp } from './app.js';

const app = new RichTerminalApp();

function cleanup() {
  app.stop();
}

process.on('SIGINT', cleanup);
process.on('SIGTERM', cleanup);
process.on('uncaughtException', (error) => {
  cleanup();
  console.error(error);
  process.exitCode = 1;
});

try {
  app.start();
} catch (error) {
  console.error(error.message);
  process.exitCode = 1;
}
