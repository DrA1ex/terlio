import { ansi, color, padEndVisible, themes, truncateVisible, visibleLength } from './ansi.js';
import { findCommand, getSuggestions, parseCommand } from './commands.js';
import { createSkillState, enabledSkillNames } from './skills.js';
import { StreamCancelled, streamMockReply } from './mockModel.js';
import { wrapText } from './wrap.js';

const MIN_COLUMNS = 48;
const MIN_ROWS = 16;
const SUGGESTION_WINDOW_SIZE = 6;

export class RichTerminalApp {
  constructor({ input = process.stdin, output = process.stdout } = {}) {
    this.input = input;
    this.output = output;
    this.running = false;
    this.busy = false;
    this.abortController = null;

    this.themeName = 'dark';
    this.theme = themes[this.themeName];
    this.skillState = this.createDefaultSkillState();

    this.messages = [];
    this.inputValue = '';
    this.cursor = 0;
    this.history = [];
    this.historyIndex = null;
    this.status = 'Ready. Type /help for commands.';
    this.suggestionIndex = 0;
    this.frame = 0;

    this.boundOnData = this.onData.bind(this);
    this.boundOnResize = this.render.bind(this);
  }

  createDefaultSkillState() {
    return createSkillState();
  }

  start() {
    if (!this.input.isTTY || !this.output.isTTY) {
      throw new Error('This app requires an interactive TTY. Run it directly in a terminal.');
    }

    this.running = true;
    this.output.write(ansi.altScreen + ansi.hideCursor + ansi.clear + ansi.home);
    this.input.setEncoding('utf8');
    this.input.setRawMode(true);
    this.input.resume();
    this.input.on('data', this.boundOnData);
    this.output.on('resize', this.boundOnResize);

    this.addSystemMessage('Mock AI Terminal запущен. Введите сообщение или начните с / для команд. Подсказки можно листать ↑/↓ и применять через Enter.');
    this.render();
  }

  stop() {
    if (!this.running) return;
    this.running = false;
    if (this.abortController) this.abortController.abort();
    this.input.off('data', this.boundOnData);
    this.output.off('resize', this.boundOnResize);
    if (this.input.isTTY) this.input.setRawMode(false);
    this.output.write(ansi.showCursor + ansi.normalScreen + ansi.reset);
    this.output.write('\n');
  }

  setTheme(name) {
    this.themeName = name;
    this.theme = themes[name] ?? themes.dark;
  }

  addSystemMessage(content) {
    this.messages.push({ role: 'system', content, streaming: false });
    this.trimMessages();
    this.render();
  }

  addUserMessage(content) {
    this.messages.push({ role: 'you', content, streaming: false });
    this.trimMessages();
    this.render();
  }

  addAssistantMessage(content = '', streaming = false) {
    const message = { role: 'ai', content, streaming };
    this.messages.push(message);
    this.trimMessages();
    this.render();
    return message;
  }

  clearMessages() {
    this.messages = [];
    this.render();
  }

  trimMessages() {
    if (this.messages.length > 200) {
      this.messages = this.messages.slice(-200);
    }
  }

  async submitInput() {
    const line = this.inputValue.trim();
    if (!line || this.busy) return;

    this.pushHistory(line);
    this.inputValue = '';
    this.cursor = 0;
    this.resetSuggestionCycle();
    this.historyIndex = null;

    if (line.startsWith('/')) {
      this.executeCommand(line);
      return;
    }

    this.addUserMessage(line);
    await this.respond(line);
  }

  executeCommand(line) {
    const { name, args } = parseCommand(line);
    const command = findCommand(name);
    if (!command) {
      this.addSystemMessage(`Неизвестная команда: ${name}. Введите /help.`);
      return;
    }
    command.run(this, args);
    this.render();
  }

  async respond(prompt) {
    this.busy = true;
    this.status = 'Model is streaming. Press Esc to cancel.';
    this.abortController = new AbortController();
    const message = this.addAssistantMessage('', true);

    try {
      await streamMockReply({
        prompt,
        enabledSkills: enabledSkillNames(this.skillState),
        signal: this.abortController.signal,
        onChunk: (chunk) => {
          message.content += chunk;
          this.render();
        },
      });
      message.streaming = false;
      this.status = 'Ready.';
    } catch (error) {
      message.streaming = false;
      if (error instanceof StreamCancelled) {
        message.content += '\n\n[response cancelled]';
        this.status = 'Stream cancelled.';
      } else {
        message.content += `\n\n[error: ${error.message}]`;
        this.status = 'Streaming failed.';
      }
    } finally {
      this.busy = false;
      this.abortController = null;
      this.render();
    }
  }

  pushHistory(line) {
    if (this.history.at(-1) !== line) this.history.push(line);
    if (this.history.length > 200) this.history = this.history.slice(-200);
  }

  onData(data) {
    const key = String(data);

    if (key === '\u0003' || key === '\u0004') {
      this.stop();
      return;
    }

    if (key === '\x1b') {
      if (this.busy && this.abortController) this.abortController.abort();
      return;
    }

    if (key === '\r' || key === '\n') {
      if (this.shouldAcceptSuggestionBeforeSubmit()) {
        this.acceptCurrentSuggestion();
      } else {
        this.submitInput();
      }
      return;
    }

    if (key === '\t') {
      this.handleSuggestionTab(1);
      return;
    }

    if (key === '\x1b[Z') {
      this.handleSuggestionTab(-1);
      return;
    }

    if (key === '\u007f' || key === '\b') {
      this.backspace();
      return;
    }

    if (key === '\x1b[3~') {
      this.deleteForward();
      return;
    }

    if (key === '\x1b[A') {
      if (!this.moveSuggestion(-1)) this.historyUp();
      return;
    }

    if (key === '\x1b[B') {
      if (!this.moveSuggestion(1)) this.historyDown();
      return;
    }

    if (key === '\x1b[C') {
      this.moveCursor(1);
      return;
    }

    if (key === '\x1b[D') {
      this.moveCursor(-1);
      return;
    }

    if (key === '\x1b[H' || key === '\x1b[1~' || key === '\u0001') {
      this.cursor = 0;
      this.render();
      return;
    }

    if (key === '\x1b[F' || key === '\x1b[4~' || key === '\u0005') {
      this.cursor = Array.from(this.inputValue).length;
      this.render();
      return;
    }

    if (isPrintable(key)) {
      this.insertText(key);
    }
  }

  insertText(text) {
    const chars = Array.from(this.inputValue);
    const inserted = Array.from(text).filter((char) => isPrintable(char)).join('');
    chars.splice(this.cursor, 0, ...Array.from(inserted));
    this.inputValue = chars.join('');
    this.cursor += Array.from(inserted).length;
    this.historyIndex = null;
    this.resetSuggestionCycle();
    this.render();
  }

  backspace() {
    const chars = Array.from(this.inputValue);
    if (this.cursor > 0) {
      chars.splice(this.cursor - 1, 1);
      this.cursor -= 1;
      this.inputValue = chars.join('');
      this.resetSuggestionCycle();
      this.render();
    }
  }

  deleteForward() {
    const chars = Array.from(this.inputValue);
    if (this.cursor < chars.length) {
      chars.splice(this.cursor, 1);
      this.inputValue = chars.join('');
      this.resetSuggestionCycle();
      this.render();
    }
  }

  moveCursor(delta) {
    const length = Array.from(this.inputValue).length;
    this.cursor = Math.max(0, Math.min(length, this.cursor + delta));
    this.render();
  }

  historyUp() {
    if (this.history.length === 0) return;
    if (this.historyIndex === null) this.historyIndex = this.history.length - 1;
    else this.historyIndex = Math.max(0, this.historyIndex - 1);
    this.inputValue = this.history[this.historyIndex] ?? '';
    this.cursor = Array.from(this.inputValue).length;
    this.resetSuggestionCycle();
    this.render();
  }

  historyDown() {
    if (this.history.length === 0 || this.historyIndex === null) return;
    if (this.historyIndex >= this.history.length - 1) {
      this.historyIndex = null;
      this.inputValue = '';
    } else {
      this.historyIndex += 1;
      this.inputValue = this.history[this.historyIndex] ?? '';
    }
    this.cursor = Array.from(this.inputValue).length;
    this.resetSuggestionCycle();
    this.render();
  }

  resetSuggestionCycle() {
    this.suggestionIndex = 0;
  }

  getCurrentSuggestions() {
    const suggestions = getSuggestions(this.inputValue);
    if (suggestions.length === 0) return [];
    this.suggestionIndex = mod(this.suggestionIndex, suggestions.length);
    return suggestions;
  }

  hasSuggestionMenu() {
    return this.inputValue.trimStart().startsWith('/') && this.getCurrentSuggestions().length > 0;
  }

  moveSuggestion(delta) {
    if (this.busy || !this.inputValue.trimStart().startsWith('/')) return false;
    const suggestions = this.getCurrentSuggestions();
    if (!suggestions.length) return false;
    this.suggestionIndex = mod(this.suggestionIndex + delta, suggestions.length);
    this.historyIndex = null;
    this.render();
    return true;
  }

  handleSuggestionTab(direction) {
    if (this.busy) return;

    if (!this.inputValue) {
      this.inputValue = '/';
      this.cursor = 1;
      this.resetSuggestionCycle();
      this.render();
      return;
    }

    const suggestions = this.getCurrentSuggestions();
    if (!suggestions.length) return;

    if (suggestions.length === 1) {
      this.acceptCurrentSuggestion();
      return;
    }

    this.moveSuggestion(direction);
  }

  shouldAcceptSuggestionBeforeSubmit() {
    if (this.busy || !this.inputValue.trimStart().startsWith('/')) return false;
    const suggestions = this.getCurrentSuggestions();
    if (!suggestions.length) return false;

    const suggestion = suggestions[this.suggestionIndex];
    if (!suggestion) return false;

    const current = this.inputValue.trim();
    const proposed = suggestion.insert.trim();
    return current !== proposed || /\s$/.test(this.inputValue);
  }

  acceptCurrentSuggestion() {
    const suggestions = this.getCurrentSuggestions();
    if (!suggestions.length) return false;

    const suggestion = suggestions[this.suggestionIndex];
    this.inputValue = suggestion.insert;
    this.cursor = Array.from(this.inputValue).length;
    this.resetSuggestionCycle();
    this.historyIndex = null;
    this.render();
    return true;
  }

  render() {
    if (!this.running) return;

    const columns = Math.max(MIN_COLUMNS, this.output.columns || 80);
    const rows = Math.max(MIN_ROWS, this.output.rows || 24);
    this.frame += 1;

    const lines = [];
    const header = this.renderHeader(columns);
    const inputBlock = this.renderInputBlock(columns);
    const suggestionBlock = this.renderSuggestions(columns);
    const status = this.renderStatus(columns);
    const fixedHeight = header.length + inputBlock.length + suggestionBlock.length + status.length;
    const transcriptHeight = Math.max(1, rows - fixedHeight);
    const transcript = this.renderTranscript(columns, transcriptHeight);

    lines.push(...header, ...transcript, ...suggestionBlock, ...status, ...inputBlock);

    while (lines.length < rows) lines.push('');

    const output = lines
      .slice(0, rows)
      .map((line) => padEndVisible(truncateVisible(line, columns), columns))
      .join('\n');

    this.output.write(ansi.home + output + ansi.reset);
  }

  renderHeader(columns) {
    const activeSkills = enabledSkillNames(this.skillState).join(', ') || 'none';
    const title = ' Mock AI Terminal ';
    const right = `theme:${this.themeName} skills:${activeSkills}`;
    const width = Math.max(0, columns - visibleLength(title) - visibleLength(right) - 2);
    const top = color(this.theme, 'border', '┌' + '─'.repeat(Math.max(0, columns - 2)) + '┐');
    const middleRaw = `${title}${' '.repeat(width)}${right}`;
    const middle = color(this.theme, 'border', '│') + color(this.theme, 'title', truncateVisible(middleRaw, columns - 2)) + color(this.theme, 'border', '│');
    const hint = ' /help  /themes  /intents  /skill on code      ↑/↓ suggestions   Enter accept/run   Esc cancel ';
    const hintLine = color(this.theme, 'border', '│') + color(this.theme, 'subtle', truncateVisible(hint, columns - 2)) + color(this.theme, 'border', '│');
    const bottom = color(this.theme, 'border', '└' + '─'.repeat(Math.max(0, columns - 2)) + '┘');
    return [top, middle, hintLine, bottom];
  }

  renderTranscript(columns, height) {
    const width = Math.max(20, columns - 4);
    const rendered = [];

    for (const message of this.messages) {
      const roleColor = message.role === 'you' ? 'user' : message.role === 'ai' ? 'assistant' : 'system';
      const label = message.role.padEnd(6);
      const prefix = color(this.theme, roleColor, `${label} `);
      const marker = message.streaming ? color(this.theme, 'accent', streamingMarker(this.frame)) : ' ';
      const content = message.content || (message.streaming ? ' ' : '');
      const wrapped = wrapText(content, width - 9, '  ');

      if (wrapped.length === 0) {
        rendered.push(prefix + marker);
      } else {
        wrapped.forEach((line, index) => {
          const left = index === 0 ? prefix + marker + ' ' : ' '.repeat(8);
          rendered.push(left + color(this.theme, 'text', line));
        });
      }
      rendered.push(color(this.theme, 'border', ' '.repeat(Math.min(columns, 1))));
    }

    const sliced = rendered.slice(-height);
    const missing = height - sliced.length;
    return [...Array(Math.max(0, missing)).fill(''), ...sliced];
  }

  renderSuggestions(columns) {
    const suggestions = this.getCurrentSuggestions();
    if (!suggestions.length) {
      const text = this.inputValue.startsWith('/')
        ? 'No command suggestions.'
        : 'Type a message, or type / to discover commands.';
      return [color(this.theme, 'muted', truncateVisible(`  ${text}`, columns))];
    }

    const activeIndex = mod(this.suggestionIndex, suggestions.length);
    const windowSize = Math.min(SUGGESTION_WINDOW_SIZE, suggestions.length);
    const start = Math.min(Math.max(activeIndex - Math.floor(windowSize / 2), 0), Math.max(0, suggestions.length - windowSize));
    const visible = suggestions.slice(start, start + windowSize);
    const above = start > 0 ? ' ↑ more' : '';
    const below = start + windowSize < suggestions.length ? ' ↓ more' : '';
    const rows = [color(this.theme, 'muted', `  Suggestions ${activeIndex + 1}/${suggestions.length}${above}${below} · ↑/↓ move · Enter accept`)];

    visible.forEach((suggestion, index) => {
      const originalIndex = start + index;
      const selected = originalIndex === activeIndex;
      const pointer = selected ? '›' : ' ';
      const label = suggestion.label.padEnd(14);
      const detail = suggestion.detail.padEnd(34);
      const row = `  ${pointer} ${label} ${detail} ${suggestion.description}`;
      rows.push(color(this.theme, selected ? 'selected' : 'suggestion', truncateVisible(row, columns)));
    });

    return rows;
  }

  renderStatus(columns) {
    const status = this.busy ? this.status : `${this.status} Active skills: ${enabledSkillNames(this.skillState).join(', ') || 'none'}.`;
    return [color(this.theme, 'border', '─'.repeat(columns)), color(this.theme, this.busy ? 'accent' : 'muted', truncateVisible(`  ${status}`, columns))];
  }

  renderInputBlock(columns) {
    const prompt = this.busy ? '… ' : '› ';
    const chars = Array.from(this.inputValue);
    const before = chars.slice(0, this.cursor).join('');
    const current = chars[this.cursor] ?? ' ';
    const after = chars.slice(this.cursor + 1).join('');
    const cursor = color(this.theme, 'selected', current);
    const line = color(this.theme, 'accent', prompt) + color(this.theme, 'input', before) + cursor + color(this.theme, 'input', after);
    return [truncateVisible(line, columns)];
  }
}

function streamingMarker(frame) {
  const frames = ['·', '•', '●', '•'];
  return frames[frame % frames.length];
}

function isPrintable(value) {
  if (!value) return false;
  if (value.startsWith('\x1b')) return false;
  for (const char of Array.from(value)) {
    const code = char.codePointAt(0);
    if (code === undefined) return false;
    if (code < 32 && char !== '\n' && char !== '\t') return false;
    if (code === 127) return false;
  }
  return true;
}

function mod(value, length) {
  return ((value % length) + length) % length;
}
