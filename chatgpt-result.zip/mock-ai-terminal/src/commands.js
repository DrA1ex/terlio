import { enabledSkillNames, formatSkillList, getSkill, skills } from './skills.js';
import { themes } from './ansi.js';
import { replyRules } from './mockModel.js';

export const commands = [
  {
    name: '/help',
    usage: '/help',
    description: 'Показать доступные команды и горячие клавиши.',
    run(app) {
      app.addSystemMessage(helpText());
    },
  },
  {
    name: '/skills',
    usage: '/skills',
    description: 'Показать список скилов и их состояние.',
    run(app) {
      app.addSystemMessage(`Скилы:\n${formatSkillList(app.skillState)}`);
    },
  },
  {
    name: '/skill',
    usage: '/skill <on|off|info> <name>',
    description: 'Включить, выключить или описать скил.',
    run(app, args) {
      const [action, name] = args;
      if (!action || !['on', 'off', 'info'].includes(action)) {
        app.addSystemMessage('Использование: /skill <on|off|info> <name>');
        return;
      }

      if (!name) {
        app.addSystemMessage(`Укажите скил. Доступно: ${skills.map((skill) => skill.name).join(', ')}`);
        return;
      }

      const skill = getSkill(name);
      if (!skill) {
        app.addSystemMessage(`Неизвестный скил: ${name}. Доступно: ${skills.map((item) => item.name).join(', ')}`);
        return;
      }

      if (action === 'info') {
        app.addSystemMessage(`${skill.title}\nname: ${skill.name}\nstate: ${app.skillState.get(skill.name) ? 'on' : 'off'}\n\n${skill.description}\n\nПодсказки: ${skill.hints.join(', ')}`);
        return;
      }

      app.skillState.set(skill.name, action === 'on');
      app.addSystemMessage(`Скил ${skill.name} ${action === 'on' ? 'включён' : 'выключен'}. Активны: ${enabledSkillNames(app.skillState).join(', ') || 'none'}.`);
    },
  },
  {
    name: '/theme',
    usage: `/theme <${Object.keys(themes).join('|')}>`,
    description: 'Сменить цветовую тему.',
    run(app, args) {
      const [themeName] = args;
      if (!themeName || !themes[themeName]) {
        app.addSystemMessage(`Использование: /theme <${Object.keys(themes).join('|')}>`);
        return;
      }
      app.setTheme(themeName);
      app.addSystemMessage(`Тема изменена: ${themeName}.`);
    },
  },
  {
    name: '/themes',
    usage: '/themes',
    description: 'Показать все доступные темы оформления.',
    run(app) {
      const rows = Object.keys(themes).map((name) => `${name === app.themeName ? 'on ' : '   '} ${name}`);
      app.addSystemMessage(`Темы оформления:\n${rows.join('\n')}\n\nСменить тему: /theme <name>`);
    },
  },
  {
    name: '/intents',
    usage: '/intents',
    description: 'Показать regex-интенты мок-модели.',
    run(app) {
      const rows = replyRules.map((rule, index) => `${String(index + 1).padStart(2, '0')}. ${rule.id.padEnd(14)} ${rule.title}`);
      app.addSystemMessage(`Regex-интенты мок-модели:\n${rows.join('\n')}\n\nМодель выбирает правило с наибольшим весом совпавших регулярных выражений.`);
    },
  },
  {
    name: '/status',
    usage: '/status',
    description: 'Показать состояние приложения, тему, скилы и размер терминала.',
    run(app) {
      const columns = app.output.columns || 80;
      const rows = app.output.rows || 24;
      app.addSystemMessage([
        'Состояние приложения:',
        `busy: ${app.busy ? 'yes' : 'no'}`,
        `theme: ${app.themeName}`,
        `skills: ${enabledSkillNames(app.skillState).join(', ') || 'none'}`,
        `messages: ${app.messages.length}`,
        `input history: ${app.history.length}`,
        `terminal: ${columns}x${rows}`,
      ].join('\n'));
    },
  },
  {
    name: '/history',
    usage: '/history [count]',
    description: 'Показать последние сообщения в виде системной сводки.',
    run(app, args) {
      const count = Math.min(50, Math.max(1, Number.parseInt(args[0] || '10', 10) || 10));
      const rows = app.messages.slice(-count).map((message, index) => {
        const text = message.content.replace(/\s+/g, ' ').trim();
        return `${String(index + 1).padStart(2, '0')}. ${message.role}: ${text.slice(0, 140)}${text.length > 140 ? '…' : ''}`;
      });
      app.addSystemMessage(rows.length ? `Последние сообщения:\n${rows.join('\n')}` : 'История пока пустая.');
    },
  },
  {
    name: '/clear',
    usage: '/clear',
    description: 'Очистить историю на экране.',
    run(app) {
      app.clearMessages();
      app.addSystemMessage('Экранная история очищена.');
    },
  },
  {
    name: '/reset',
    usage: '/reset',
    description: 'Сбросить экран, историю ввода, тему и скилы к значениям по умолчанию.',
    run(app) {
      app.clearMessages();
      app.history = [];
      app.historyIndex = null;
      app.setTheme('dark');
      app.skillState = app.createDefaultSkillState();
      app.addSystemMessage('Состояние сброшено: тема dark, история очищена, скилы возвращены к значениям по умолчанию.');
    },
  },
  {
    name: '/about',
    usage: '/about',
    description: 'Кратко описать назначение прототипа.',
    run(app) {
      app.addSystemMessage('Mock AI Terminal — dependency-free прототип rich-terminal оболочки для AI-чата. Модель пока моковая, но ввод, команды, скилы, темы, regex-интенты и streaming-контракт уже отделены от будущего AI-провайдера.');
    },
  },
  {
    name: '/exit',
    usage: '/exit',
    description: 'Завершить приложение.',
    run(app) {
      app.stop();
    },
  },
];

export function parseCommand(line) {
  const parts = line.trim().split(/\s+/).filter(Boolean);
  const name = parts[0];
  const args = parts.slice(1);
  return { name, args };
}

export function findCommand(name) {
  return commands.find((command) => command.name === name);
}

export function getSuggestions(input) {
  const value = input.trimStart();
  if (!value.startsWith('/')) return [];

  const endsWithSpace = /\s$/.test(input);
  const tokens = value.split(/\s+/).filter(Boolean);
  const commandToken = tokens[0] ?? '';

  if (tokens.length <= 1 && !endsWithSpace) {
    return commands
      .filter((command) => command.name.startsWith(commandToken))
      .map((command) => ({
        insert: command.name + (command.usage.includes('<') || command.usage.includes('[') ? ' ' : ''),
        label: command.name,
        detail: command.usage,
        description: command.description,
      }));
  }

  if (commandToken === '/skill') {
    const actionToken = tokens[1] ?? '';
    if (tokens.length === 1 || (tokens.length === 2 && !endsWithSpace)) {
      return ['on', 'off', 'info']
        .filter((action) => action.startsWith(actionToken))
        .map((action) => ({
          insert: `/skill ${action} `,
          label: action,
          detail: `/skill ${action} <name>`,
          description: action === 'on' ? 'Включить скил.' : action === 'off' ? 'Выключить скил.' : 'Показать описание скила.',
        }));
    }

    const nameToken = tokens[2] ?? '';
    return skills
      .filter((skill) => skill.name.startsWith(nameToken))
      .map((skill) => ({
        insert: `/skill ${tokens[1]} ${skill.name}`,
        label: skill.name,
        detail: skill.title,
        description: skill.description,
      }));
  }

  if (commandToken === '/theme') {
    const themeToken = tokens[1] ?? '';
    return Object.keys(themes)
      .filter((theme) => theme.startsWith(themeToken))
      .map((theme) => ({
        insert: `/theme ${theme}`,
        label: theme,
        detail: `theme ${theme}`,
        description: 'Переключить визуальную тему терминала.',
      }));
  }

  if (commandToken === '/history') {
    const countToken = tokens[1] ?? '';
    return ['5', '10', '20', '50']
      .filter((count) => count.startsWith(countToken))
      .map((count) => ({
        insert: `/history ${count}`,
        label: count,
        detail: `/history ${count}`,
        description: `Показать последние ${count} сообщений.`,
      }));
  }

  return [];
}

export function helpText() {
  const commandRows = commands.map((command) => `${command.usage.padEnd(44)} ${command.description}`).join('\n');
  return [
    'Команды:',
    commandRows,
    '',
    'Клавиши:',
    'Tab / Shift+Tab                              перейти по подсказкам; если подсказка одна — применить её',
    '↑ / ↓                                        выбрать подсказку, если открыт список команд; иначе история ввода',
    'Enter                                        применить выбранную подсказку или выполнить введённую команду',
    '← / →, Home / End                            перемещение по строке',
    'Esc                                          отменить текущий потоковый ответ',
    'Ctrl+C / Ctrl+D                              выход',
  ].join('\n');
}
